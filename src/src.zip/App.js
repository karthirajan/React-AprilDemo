import './App.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

import Signup from './pages/signup/Signup'

function App() {
  return (
    <div className="App">
     <Signup/>
    </div>
  );
}

export default App;
