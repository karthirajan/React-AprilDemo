import React, { Component } from 'react'
import logo from './images/Stage_A_Dream_Logo.png'

export default class Signup extends Component {
    state = {
        username: '',
        fullname: '',
        mobileNumber: '',
        dateOfBirth: '',
        gender: '',
        password: '',
        confirmPassword: '',
    };

    handleChange = (event) => {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    };

    handleSubmit = (event) => {
        event.preventDefault();
        // Add code here to send form data to server
    };

    render() {
        return (
            <>
                <section className="home">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            
                        </div>
                        <div class="col sign-up">
                            <form onSubmit={this.handleSubmit}>
                                <div>
                                    <img src={logo} className="sd_logo center-block d-block mx-auto" alt="" />
                                </div>
                                <div>
                                    <input
                                        placeholder="Username"
                                        type="text"
                                        name="username"
                                        value={this.state.username}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <div>
                                    <input
                                    placeholder="Full Name"
                                        type="text"
                                        name="fullname"
                                        value={this.state.fullname}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <div>
                                    <input
                                    placeholder="Mobile Number"
                                        type="tel"
                                        name="mobileNumber"
                                        value={this.state.mobileNumber}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <div>
                                    <input
                                        placeholder="Date of Birth"
                                        type="date"
                                        name="dateOfBirth"
                                        value={this.state.dateOfBirth}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <div>
                                    <select
                                        placeholder="Gender"
                                        name="gender"
                                        value={this.state.gender}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    >
                                        <option value="">Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div>
                                    <input
                                    placeholder="Password"
                                        type="password"
                                        name="password"
                                        value={this.state.password}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <div>
                                    <input
                                        placeholder="Confirm Password"
                                        type="password"
                                        name="confirmPassword"
                                        value={this.state.confirmPassword}
                                        onChange={this.handleChange}
                                        required
                                        class="rounded-pill"
                                    />
                                </div>
                                <button type="submit" class="rounded-pill">Sign Up</button>
                                <br />
                                <p class="text-center login-route">Already a User? <a href="">Login</a></p>
                            </form>
                        </div>
                    </div>
                </div>

                </section>          
            </>
        )
    }
}

